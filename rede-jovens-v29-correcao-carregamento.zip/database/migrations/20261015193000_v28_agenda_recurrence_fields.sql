-- Recorrência opcional para itens da Agenda.
-- A migração v28 foi aplicada diretamente no projeto Supabase.
alter table public.events
  add column if not exists recurrence_type text not null default 'none';

alter table public.events
  add column if not exists recurrence_until date;

alter table public.events
  drop constraint if exists events_recurrence_type_chk;

alter table public.events
  add constraint events_recurrence_type_chk
  check (recurrence_type in ('none', 'weekly', 'monthly', 'yearly'));
