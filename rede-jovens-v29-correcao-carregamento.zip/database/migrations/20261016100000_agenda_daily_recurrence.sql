-- Habilita recorrência diária na Agenda sem alterar os demais valores permitidos.
alter table public.events
  drop constraint if exists events_recurrence_type_chk;

alter table public.events
  add constraint events_recurrence_type_chk
  check (recurrence_type in ('none', 'daily', 'weekly', 'monthly', 'yearly'));
