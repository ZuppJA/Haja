alter table public.profiles
  add column if not exists agenda_access text not null default 'viewer'
  check (agenda_access in ('editor','viewer'));

update public.profiles set agenda_access = case when role::text = 'admin' then 'editor' else 'viewer' end;

drop policy if exists events_insert on public.events;
drop policy if exists events_update on public.events;
drop policy if exists events_delete on public.events;
drop policy if exists events_select on public.events;

create policy events_agenda_select on public.events for select to authenticated using (exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.active=true and p.agenda_access in ('editor','viewer')));
create policy events_agenda_insert on public.events for insert to authenticated with check (created_by=(select auth.uid()) and exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.active=true and p.agenda_access='editor'));
create policy events_agenda_update on public.events for update to authenticated using (exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.active=true and p.agenda_access='editor')) with check (updated_by=(select auth.uid()) and exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.active=true and p.agenda_access='editor'));
create policy events_agenda_delete on public.events for delete to authenticated using (exists (select 1 from public.profiles p where p.id=(select auth.uid()) and p.active=true and p.agenda_access='editor'));
