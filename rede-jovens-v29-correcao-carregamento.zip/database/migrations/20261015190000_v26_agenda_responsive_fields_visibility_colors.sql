begin;

alter table public.events
  add column if not exists congregation_name text,
  add column if not exists display_color text not null default '#E8F0E8';

alter table public.events drop constraint if exists events_visibility_chk;

create or replace function private.validate_agenda_item()
returns trigger
language plpgsql
set search_path = public, pg_catalog
as $function$
begin
  new.agenda_type := coalesce(nullif(trim(new.agenda_type), ''), 'event');
  new.visibility := coalesce(nullif(trim(new.visibility), ''), 'public');
  new.congregation_name := nullif(trim(new.congregation_name), '');
  new.department_id := null;
  new.display_color := coalesce(nullif(trim(new.display_color), ''), '#E8F0E8');

  if new.visibility not in ('public', 'private') then
    raise exception using errcode = '22023', message = 'Visibilidade de agenda inválida.';
  end if;

  if new.display_color not in (
    '#E8F0E8','#E8EEF7','#F4E8DC','#F3E6EA','#EDE8F6',
    '#E5F0EF','#F3EEDB','#F0E9E0','#E7EDF1','#F1E8DD'
  ) then
    raise exception using errcode = '22023', message = 'Cor de agenda inválida.';
  end if;

  return new;
end;
$function$;

update public.events
set visibility = 'public'
where visibility is null or visibility not in ('public','private');

update public.events e
set congregation_name = coalesce(nullif(btrim(e.congregation_name), ''), c.name)
from public.congregations c
where e.congregation_id = c.id
  and (e.congregation_name is null or btrim(e.congregation_name) = '');

update public.events
set display_color = '#E8F0E8'
where display_color is null
   or display_color not in (
    '#E8F0E8','#E8EEF7','#F4E8DC','#F3E6EA','#EDE8F6',
    '#E5F0EF','#F3EEDB','#F0E9E0','#E7EDF1','#F1E8DD'
   );

alter table public.events
  add constraint events_visibility_chk check (visibility in ('public','private'));
alter table public.events alter column display_color set default '#E8F0E8';
alter table public.events alter column display_color set not null;
alter table public.events drop constraint if exists events_display_color_chk;
alter table public.events
  add constraint events_display_color_chk check (display_color in (
    '#E8F0E8','#E8EEF7','#F4E8DC','#F3E6EA','#EDE8F6',
    '#E5F0EF','#F3EEDB','#F0E9E0','#E7EDF1','#F1E8DD'
  ));

drop policy if exists events_agenda_select on public.events;
drop policy if exists events_agenda_select_public_or_editor on public.events;
create policy events_agenda_select_public_or_editor
on public.events for select to authenticated
using (
  visibility = 'public'
  or exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid())
      and p.active = true
      and p.agenda_access = 'editor'
  )
);

create or replace function private.guard_profile_privileged_fields()
returns trigger
language plpgsql
security definer
set search_path = public, private
as $$
begin
  if (
    new.role is distinct from old.role
    or new.agenda_access is distinct from old.agenda_access
    or new.active is distinct from old.active
  ) and not private.is_admin() then
    raise exception 'Only an administrator can change account permissions or status.'
      using errcode = '42501';
  end if;
  return new;
end;
$$;

drop trigger if exists guard_profile_privileged_fields on public.profiles;
create trigger guard_profile_privileged_fields
before update on public.profiles
for each row execute function private.guard_profile_privileged_fields();

commit;
