begin;

alter table public.events alter column visibility set default 'public';

drop policy if exists events_agenda_select_public_or_editor on public.events;
create policy events_agenda_select_public_or_editor
on public.events for select to authenticated
using (
  exists (
    select 1
    from public.profiles p
    where p.id = (select auth.uid())
      and p.active = true
      and p.agenda_access in ('editor','viewer')
      and (public.events.visibility = 'public' or p.agenda_access = 'editor')
  )
);

commit;
