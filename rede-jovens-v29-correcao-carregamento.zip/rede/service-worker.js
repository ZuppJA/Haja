/* Rede-Jovens PWA: cache only the app shell; never cache Supabase/API calls. */
'use strict';
const CACHE_NAME = 'rede-jovens-shell-v3';
const BASE_URL = self.registration.scope;
const APP_ROOT_URL = new URL('./', BASE_URL);
const INDEX_URL = new URL('./index.html', BASE_URL);
const APP_PATHS = new Set([APP_ROOT_URL.pathname, INDEX_URL.pathname]);
const SHELL_FILES = [
  APP_ROOT_URL.href,
  INDEX_URL.href,
  new URL('./app.js', BASE_URL).href,
  new URL('./site.webmanifest', BASE_URL).href,
  new URL('./assets/brand/haja-simbolo.svg', BASE_URL).href,
  new URL('./assets/icons/favicon.ico', BASE_URL).href,
  new URL('./assets/icons/favicon.svg', BASE_URL).href,
  new URL('./assets/icons/apple-touch-icon.png', BASE_URL).href,
  new URL('./assets/icons/app-icon-192.png', BASE_URL).href,
  new URL('./assets/icons/app-icon-512.png', BASE_URL).href
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(SHELL_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(key => key.startsWith('rede-jovens-') && key !== CACHE_NAME)
          .map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Only cache the app shell routes; do not persist invite/auth query strings.
  if (request.mode === 'navigate') {
    if (!APP_PATHS.has(url.pathname)) return;
    const cacheKey = new URL(url.pathname, url.origin).href;
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response && response.ok) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(cacheKey, response.clone());
        }
        return response;
      } catch (_) {
        return (await caches.match(cacheKey))
          || (await caches.match(INDEX_URL.href))
          || (await caches.match(APP_ROOT_URL.href))
          || Response.error();
      }
    })());
    return;
  }

  if (SHELL_FILES.includes(url.href)) {
    event.respondWith((async () => {
      const cached = await caches.match(request);
      if (cached) return cached;
      const response = await fetch(request);
      if (response && response.ok) {
        const cache = await caches.open(CACHE_NAME);
        await cache.put(request, response.clone());
      }
      return response;
    })());
  }
});
