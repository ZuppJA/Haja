# Rede-Jovens — pacote organizado

## Estrutura

- `rede/`: arquivos que devem ser publicados no diretório público do site.
  - `index.html`: página principal.
  - `app.js`: lógica da aplicação carregada pelo HTML (mantida em um único lugar).
  - `service-worker.js`: cache do shell do PWA; não armazena chamadas nem dados do Supabase.
  - `site.webmanifest`: configuração de instalação como aplicativo.
  - `assets/brand/`: logotipo vetorial utilizado na interface.
  - `assets/icons/`: favicon, ícone para iOS e ícones de instalação do PWA.
- `database/migrations/`: histórico SQL para manutenção do banco. Esta pasta **não** precisa ser enviada para a hospedagem estática.

## Publicação

1. Publique o conteúdo de `rede/` no diretório público do site, mantendo a estrutura de `assets/`.
2. Mantenha a publicação em HTTPS para ativar o service worker e os recursos instaláveis.
3. Não envie `database/` para o diretório público da hospedagem. Execute migrações somente quando necessário, pelo fluxo administrativo do Supabase.
4. Após atualizar um site já instalado, abra-o online para que o service worker receba a versão nova.

## Organização de imagens

Foram removidas cópias redundantes de ícones (os PNG `icon-*` eram duplicados de `app-icon-*`, e `app-icon-180.png` duplicava `apple-touch-icon.png`). Também foram removidas exportações de logo que não eram referenciadas pelo site. Os arquivos originais de migração foram preservados.

## Nota de funcionamento

O site carrega a biblioteca do Supabase e os dados online. O cache PWA cobre somente os arquivos estáticos; não transforma o banco nem a autenticação em modo offline.


## Solução de problemas no Android

Se o navegador ficar permanentemente em “Carregando Agenda da Igreja…” e a barra de endereço mostrar `content://media/external/file/...`, a página foi aberta diretamente pelo gerenciador de arquivos. Nesse modo, o Android/Chrome pode não disponibilizar os arquivos vizinhos (`app.js`, imagens e manifesto) para a página, por isso o JavaScript da aplicação não inicia.

**Não abra o `index.html` diretamente dentro do ZIP nem pelo gerenciador de arquivos.** Publique todos os arquivos que estão dentro de `rede/` em uma hospedagem web e acesse pelo endereço `https://...`. Isso é necessário para que os arquivos relativos sejam carregados e para habilitar o service worker e a instalação do PWA. O projeto exige conexão ao Supabase para autenticação e dados.

A tela inicial agora mostra uma orientação automática após 4 segundos caso o código da aplicação não consiga substituir o carregamento. Também foi incrementada a versão do cache do service worker para solicitar os arquivos atualizados após a publicação.
